# Hospital Reviva — Memorial, Estado e Roadmap do Sistema
**Documento vivo · última atualização: 21/07/2026**

Este é o documento de referência único do sistema. Ele cumpre três papéis:
1. **Memorial de atualizações** — o que já foi construído, em ordem (seção 2).
2. **Estado do sistema** — checklist para conferir o que está no ar, banco e telas (seção 3).
3. **Evoluções futuras** — o que vem nas próximas fases, priorizado (seção 4).

A cada nova versão entregue, este documento é atualizado junto. Ele substitui o antigo `CHECKLIST-estado-do-sistema.md` (incorporado aqui na seção 3).

---

## 1. Arquitetura em uma frase

Frontend estático (HTML/JS, sem build) hospedado na Vercel + backend Supabase/Postgres. **No Livro de Registro e no BMPO, a identidade do medicamento é princípio ativo + dosagem** — o nome comercial é conveniência clínica e é consolidado na escrituração. Login único (Supabase Auth). O **razão é derivado** — saldos e Livro são calculados a partir dos eventos atômicos, nunca digitados à mão. RT e estabelecimento são **dados editáveis** (Configurações), nunca fixos no código. Migrações são **aditivas** e ficam na pasta `db/`.

---

## 2. Memorial de atualizações

### Versão atual — 21/07/2026
Mudanças mais recentes, da mais nova para a mais antiga:

- **Sinais Vitais para todos os pacientes de uma vez.** O seletor ganhou a opção **★ TODOS os pacientes internados**, que gera uma folha para cada um (em ordem alfabética, com o cabeçalho preenchido e quebra de página entre elas). Combinada com o número de folhas, permite imprimir o bloco inteiro da unidade de uma só vez. Pacientes com alta ficam de fora automaticamente.
- **Exportar cotação para Excel (.xlsx).** Botão **⬇ Exportar Excel** na cotação, gerando a planilha para enviar ao fornecedor: cabeçalho da clínica, identificador e data, itens ordenados por categoria e nome, coluna **Lista 344/98** marcando os controlados, e sete **colunas em branco para o fornecedor preencher** (marca/laboratório, unid. por caixa, preço por caixa, preço unitário, validade, prazo de entrega, observação). Sai com autofiltro, painel congelado e larguras ajustadas. Usa SheetJS via CDN, com queda automática para CSV caso a biblioteca não carregue.

- **Sessão expirada com aviso claro.** A queda de sessão era silenciosa e só aparecia ao gravar, com a mensagem técnica de RLS. Agora a sessão é verificada a cada 2 minutos e ao voltar para a aba, e qualquer falha de gravação por sessão perdida vira um aviso legível ("Sua sessão expirou… nada foi gravado"), com botões para reentrar na mesma aba ou em outra. O **formulário permanece preenchido**, bastando salvar de novo após o login.
- **Substâncias em ordem alfabética por categoria.** Todos os seletores de substância (prescrição, ajuste, NF, doação, custódia…) passaram a ser agrupados por categoria em ordem alfabética, com os itens ordenados por nome, marcando a lista de controle e a origem (med. de paciente). O **menu Substâncias/Estoque** também foi agrupado por categoria, com contagem de itens, nº de controlados e valor em estoque por categoria. Os **lotes no ajuste** ficaram agrupados por substância.
- **Ajuste de vários lotes com a mesma justificativa.** Novo formulário "Ajuste de vários lotes": adiciona-se quantas linhas forem necessárias (lote + contagem física), com a diferença calculada ao vivo e um resumo do que será lançado. Cada divergência gera seu próprio lançamento no Livro (rastreável por lote), todos com a **mesma data e justificativa**; lotes que conferem não geram lançamento.
- **Folha de Sinais Vitais: coluna PA alargada.** A coluna de pressão arterial passou a 13% da largura (contra 8,5% das numéricas), acomodando o padrão manuscrito 120 X 80, e ganhou a unidade no cabeçalho (PA em mmHg).

- **Nova seção Enfermagem — Documentos e Registros (`enfermagem.html`).** Área para as folhas próprias da enfermagem, **somente impressão** (não grava dados, não criou tabelas). Primeiro documento: **Sinais Vitais**, com logotipo e cabeçalho da clínica, bloco de identificação do paciente (nome, idade, sexo, prontuário, leito, data de internação) e as colunas Data · Hora · PA · FC (bpm) · SpO₂ (%) · Temperatura (°C) · HGT · Assinatura da Enfermagem. Pode sair **com o cabeçalho do paciente preenchido** ou **em branco** para preenchimento manual, com número de linhas e de folhas configurável. A estrutura é um catálogo (`_ENF_DOCS`), pronta para receber os próximos impressos da enfermagem. *(Front-only.)*

- **Mapa ordenado por período de administração.** As linhas de cada paciente passaram a sair na ordem definida pelo RT: **JEJUM no topo**, depois manhã · manhã/tarde · manhã/noite · manhã/tarde/noite · tarde · tarde/noite · noite, e **SOS por último**. A regra geral aplicada é: período em que começa → período em que termina → número de períodos, o que acomoda também as combinações não listadas (ex.: manhã/noite, que é o padrão atual da clínica às 09:00 e 21:00).
- **Horários padronizados clicáveis.** A prescrição ganhou chips de horário (JEJUM · 06:00 · 09:00 · 12:00 · 15:00 · 18:00 · 21:00 · 00:00 · SOS) que alternam com um clique e se ordenam sozinhos; o campo de texto continua disponível para horários fora do padrão. Isso garante grafia uniforme, de que depende a ordenação do mapa. **JEJUM** ocupa a coluna da manhã e sobe ao topo; **SOS** não ocupa coluna e desce ao final.

- **Meia dose (fração) com descarte do restante.** A prescrição passou a aceitar **quantidade fracionada por horário** (0,25 / 0,5 / 0,75). O sistema distingue **dose administrada** de **quantidade consumida do estoque**: em formas sólidas (comprimido, cápsula, drágea), partir a unidade descarta o restante, então administra-se a fração e o **estoque baixa a unidade inteira** (½ comp. em 2 horários = 2 comprimidos/dia). Em formas líquidas não há descarte e o consumo é igual ao administrado. O mapa e as telas mostram a fração como **½ / ¼ / ¾** (ex.: "½ comp./dose"), e a tela de dispensação indica quanto está sendo baixado e descartado. Sem migração — o banco já aceitava valores fracionados. *(Front-only.)*

- **Cotação impressa por categoria em ordem alfabética.** A **Solicitação de Cotação** (documento enviado ao fornecedor) passou a sair agrupada por categoria, com **categorias e itens em ordem alfabética**, contagem de itens por categoria, tag da lista (B1/C1) em cada controlado e aviso de "contém itens sob controle especial" nas categorias aplicáveis — mantendo as colunas em branco para o fornecedor preencher embalagem, preço e validade. A mesma ordenação alfabética foi aplicada ao **Pedido de Compra**, ao seletor de itens e à **lista de itens na tela**. *(Front-only.)*

- **Categorias de medicamento e separação padronização x paciente (`migration_categorias.sql`).** Cada substância ganhou **categoria** (10 categorias clínicas, das psicotrópicas às de urgência) e o marcador **padronizado**. A cotação passou a trabalhar só com itens da **padronização** — medicação cadastrada por causa de custódia de paciente não entra em cotação nem no "adicionar todos". O **Pedido de Compra impresso** agora sai **agrupado por categoria**, com subtotal por categoria, tag da lista (B1/C1) em cada item e aviso de "contém itens sob controle especial" nas categorias que têm controlados. No cadastro de substância há os campos Categoria e Origem (padronização / medicação de paciente), e a lista de estoque marca com tag as medicações de paciente.

- **Padronização aprovada cadastrada (`migration_padronizacao.sql`).** 77 substâncias da padronização aprovada pela diretoria, com a **classificação da Portaria 344/98 conferida item a item**: 6 em **B1** (benzodiazepínicos → Notificação B azul), 33 em **C1** (antidepressivos, anticonvulsivantes, antipsicóticos, antiparkinsonianos → Receita de Controle Especial 2 vias) e 38 não controladas. A migração também cria a **primeira cotação (COT-2026-001)** já com os 77 itens e as quantidades aprovadas (comprimidos 1 caixa, líquidos 2 frascos, injetáveis 10 ampolas). Correções apuradas na conferência: **prometazina não é controlada** (exceção expressa da 344/98) e **bromazepam é B1**. *(Idempotente.)*

- **Folha de Registro Semanal (para transcrição ao livro físico).** Nova impressão na tela de Escrituração: escolhe-se a semana (segunda a domingo, com navegação ◀ ▶) e o sistema gera uma folha com um bloco por medicamento contendo **saldo anterior**, **entradas discriminadas por lote** (data, lote, validade, origem/documento), **saídas consolidadas do período** (total + nome de um paciente seguido de "e outros" quando houver mais de um) e **saldo final**, além de campo "Transcrito no livro em ___ / Rubrica". Por padrão traz só os controlados, com opção de incluir os demais.
- **Identidade do medicamento no Livro e no BMPO: PRINCÍPIO ATIVO + DOSAGEM.** Nomes comerciais distintos com mesmo princípio e dosagem passam a ser **um único item** na escrituração — o nome comercial serve à administração pela enfermagem e à prescrição médica. Novo agrupamento (`gruposSubstancias`) aplicado à Folha Semanal e ao **BMPO**, que antes emitia uma linha por nome comercial e agora emite **uma linha por princípio+dosagem**, listando os nomes comerciais como referência.

- **Padronização de entrada em MAIÚSCULAS.** A digitação de texto passa a ser normalizada para maiúsculo automaticamente em todos os cadastros, **exceto POPs** (texto livre) e **exceto** e-mail, senha, números, datas e seletores (que guardam os IDs). Preserva a posição do cursor e permite exceção pontual via classe `no-upper`. Para os dados já cadastrados, há o script opcional **`migration_maiusculas.sql`** (idempotente, não toca e-mails/IDs/POPs nem campos de valor controlado como o canal da NF). *(Front em layout.js + SQL opcional.)*

- **Backup Exportar/Importar (Configurações → Backup e Segurança).** Botão **Exportar backup** baixa um JSON com **todas as 26 tabelas** (com data, assinatura e total de registros) para guardar fora do Supabase (Drive/pen drive). Botão **Restaurar de um arquivo** reconstrói os dados — em projeto vazio apenas insere; em projeto com dados, exige digitar RESTAURAR e substitui tudo. Ordem de tabelas respeita as chaves estrangeiras (limpeza reversa, inserção direta). Restaura **dados**; o schema vem das migrações. Validado em ciclo completo (export → restaurar por cima → restaurar em vazio) com contagens idênticas. *(Front-only, assets/backup.js.)*

- **POP-FAR-001 — Sistema de Gestão da Qualidade da Farmácia.** POP mestre que rege todos os demais: define elaboração, aprovação, treinamento, disponibilidade, revisão programada e **revisão extraordinária** (mudança de legislação, orientação da Vigilância, mudança de estrutura, não conformidade, sugestão da equipe), controle de versões, tratamento de **não conformidades e ações corretivas**, acompanhamento normativo, **resposta a fiscalizações com plano de ação** e autoavaliação periódica — formalizando a **melhoria contínua**. Total: **14 POPs**. *(Rodar `pops_conteudo_v4.sql`.)*
- **POPs em ordem de código.** A relação passou a ser ordenada por código — todos os **FAR** primeiro, depois os **ENF**, em numeração crescente — na tela e no Registro Mestre.
- **Correção — botão "Sair" invisível.** Na barra lateral escura, o botão usava a fonte na mesma cor do fundo (#1D4744), só aparecendo no hover. Passou a usar texto claro com borda sutil (contraste de 1,0:1 para 8,6:1).

- **Folha de Prescrição Médica (prontuário).** Documento interno da consulta, para arquivo no prontuário (sem vias nem retenção). Traz cabeçalho do estabelecimento, identificação do paciente (nome, prontuário, leito, idade, data de internação), **campo de alergias em destaque**, tabela de medicações (nº, medicamento, dose, via, frequência/observações), bloco de **cuidados/orientações** e assinatura/CRM do médico. Pré-preenchida com **todas as medicações ativas** do paciente (controladas e não) ou **em branco** para preencher à mão. Botões na prescrição do paciente e na tela geral de Prescrições. *(Front-only.)*

- **Correção — prescrição suspensa saindo do mapa.** Medicação suspensa deixou de aparecer no **mapa de medicação**, na **dispensação** e nos **cartões de prescrição** (o histórico é preservado e pode ser consultado). O filtro por `ativo` foi aplicado em mapa.js, dose.js e prescricoes.js.
- **Receituários em branco (sem paciente).** Além do pré-preenchido, agora há botões na **tela geral de Prescrições** para imprimir **Receituário C e comum em branco** (com pautas para o médico preencher à mão), seguindo o layout do modelo usado em clínica (Paciente/Endereço/Prescrição em linhas). Emitente do estabelecimento no cabeçalho.

- **Receituários imprimíveis (na Prescrição do paciente).** Dois botões na prescrição do paciente: **Receituário de Controle Especial (C)** — branca, **2 vias** (1ª Farmácia / 2ª Paciente), com campo de numeração, blocos de retenção (comprador/fornecedor) e itens **lista C1** pré-preenchidos — e **Receituário comum** (via única, itens **não controlados**). Ambos pré-preenchem estabelecimento, prescritor e paciente. Itens **B1/B2 (benzos)** e **A (opioides)** são excluídos dos dois, pois exigem Notificação B/A com numeração da VISA. *(Front-only, sem migração.)*

- **Qualificação de fornecedores.** Cada fornecedor ganhou uma **qualificação leve**: habilitação documental (checks de AFE, Licença, Certidões, Tabela + vencimento) e **avaliação de desempenho** em Bom/Regular/Ruim (prazo de entrega, tempo de resposta, atendimento), além de situação (ativo/em qualificação/inativo). Tags aparecem ao lado do fornecedor na cotação (🟢/🟡/🔴 e ⚠ não habilitado); ao lançar preços de um fornecedor com documentação incompleta/vencida, o sistema **alerta sem bloquear**. *(Requer `migration_fornecedor_qualif.sql`.)*

- **POPs — fluxo completo redigido (13/13).** Redigidos os POPs restantes, no mesmo padrão (atribuição + base legal; regime presencial periódico): **Admissão e Cadastro** (FAR-006), **Conferência e Registro da Administração** (ENF-002, no lugar de "dupla checagem", que a estrutura atual não comporta), **Devolução e Reintegração** (FAR-008), **Carrinho/Maleta de Emergência e Lacre** (FAR-010), **Cotação e Aquisição** (FAR-012) e **Backup e Continuidade** (FAR-013). Agora **os 13 POPs do fluxo têm documento**. *(Rodar `pops_conteudo_v3.sql`.)*

- **POPs — conteúdo v2 (enquadramento legal + mais POPs).** Os POPs foram reescritos para descrever o processo **por atribuição e com base legal**, não pela ausência de recursos: o preparo é **atribuição da enfermagem** (Lei 7.498/1986; Decreto 94.406/1987), com assistência farmacêutica em **regime presencial periódico** e retaguarda à distância — sem citar "falta de auxiliar" nem dias fixos, o que protege a instituição em fiscalização. Além dos 3 iniciais, foram redigidos: **Conferência de NF** (FAR-002), **Doações** (FAR-003), **Destino da Custódia na Alta** (FAR-005) e **Escrituração e Balanço** (FAR-011). Total: **7 POPs com documento**. *(Rodar `pops_conteudo_v2.sql`.)*

- **POPs — Camada 2 (gerador de documento).** Cada POP passou a ter **corpo estruturado** (objetivo, campo de aplicação, responsabilidades, materiais, procedimento passo a passo, registros, referências), editável na tela, e **impressão do documento de POP formatado** com cabeçalho de controle e bloco de assinaturas (elaborado/revisado/aprovado). Três POPs prioritários já vêm redigidos **dentro da realidade atual da clínica** (enfermagem prepara e administra no horário; RT confere custódia e estoque quando presencial, com suporte remoto por WhatsApp): **Preparo e Administração pela Enfermagem** (POP-ENF-001), **Custódia** (POP-FAR-004) e **Conferência Presencial do Estoque** (POP-FAR-009). *(Requer `migration_pops_corpo.sql`; conteúdo inicial em `pops_conteudo_inicial.sql`.)*

- **POPs — Camada 1 (registro funcional).** A área de POPs deixou de ser um checklist estático: agora é um registro com **CRUD**, **status clicável** (Pendente → Em elaboração → Vigente), campos de controle (**código, versão, data de vigência, próxima revisão, responsável, observação**), sinalização de **revisão vencida/próxima** e **impressão do Registro Mestre de POPs**. Os **13 tópicos do fluxo** passaram a ser **permanentes** (não mais dado de teste) e incluem os módulos novos (destino da custódia na alta, ajuste/contagem de inventário, cotação). *(Requer `migration_pops.sql`.)*

- **Livro de Registro — lote e validade.** Cada lançamento passou a exibir o **lote** e a **validade** (na tela e no impresso), e há **filtro por lote** (restrito à substância escolhida quando houver uma).
- **Livro de Registro — filtros.** Filtro por **paciente**, **período (de/até)**, **tipo de movimento** (entradas, saídas, devoluções, ajustes de inventário), **substância** e **lista/classe** (controlados). Os filtros valem para tela e impressão; o subtítulo do impresso descreve o recorte. O **Saldo após permanece o saldo real acumulado** — os filtros só escolhem quais linhas aparecem, nunca recalculam o saldo dentro do recorte.
- **Prescrições agrupadas por paciente.** A tela deixou de ser uma lista plana: agora há **um cartão por paciente**; abre-se a prescrição completa dele e edita-se item a item (editar, suspender, adicionar). **Filtro por paciente** no topo.
- **Quantidade por horário na prescrição.** Campo **Qtd. por horário** (padrão 1) permite dispensar mais de um comprimido por dose. A dispensação usa o número direto; tela e mapa exibem "2×/horário" / "2×/dose". *(Requer `migration_qtd_dose.sql`.)*
- **Folha de contagem / inventário.** Botão na aba Ajuste de Estoque que gera folha A4 com Substância · Lote · Validade · Saldo no sistema + colunas em branco **Contagem física** e **Diferença**. Filtros: **substância**, **faixa de vencimento** (todas / vencidas / 30·60·90 dias / intervalo) e **ocultar zerados**.
- **Mapa por paciente + opções.** Formato "por paciente" repete o bloco do dia (Manhã/Tarde/Noite) empilhado por dia, uma folha por paciente. Opção de **fichas em branco** para novos pacientes e liga/desliga para **ignorar pacientes sem prescrição**.
- **Alta de paciente e destino da custódia.** Botão "Dar alta" (encerra prescrições, libera leito, arquiva). Custódia com saldo fica **aguardando retirada**; depois o RT decide item a item: **devolver à família** (com Termo de Devolução) ou **integrar ao estoque** (passa a contar no BMPO). Aba **Arquivo** com histórico preservado e **Extrato de Alta** em duas versões (com/sem valores). *(Requer `migration_alta.sql`.)*
- **Cotação de compras — Fase B.** Lançar preços por fornecedor (unid./caixa, preço/caixa, validade, indisponível), **comparativo por preço unitário** com o vencedor destacado, e **pedidos por fornecedor** imprimíveis. *(Requer `migration_cotacao.sql`.)*

### Base consolidada (fases anteriores)
- **Núcleo.** Banco (schema + RLS), login, Configurações (RT + estabelecimento).
- **Cadastros e estoque.** Pacientes, Substâncias/Estoque (lote, validade, FEFO), Notas Fiscais, Doações.
- **Prescrição e dispensação.** Prescrição multi-substância; **Dose Unitária** com **seleção de data** (baixa retroativa), preferência pelo **lote de custódia do próprio paciente** (★) e estoque geral como escolha manual; devolução/estorno.
- **Custódia (medicação própria).** Registro + Termo de Custódia; restrita ao paciente que trouxe.
- **Mapa de medicação — por dia.** Uma folha por dia com todos os pacientes; períodos Manhã/Tarde/Noite; linhas e fichas em branco.
- **Inventário/ajustes.** Ajuste justificado (contagem física vs sistema) que reconcilia o saldo via movimentação. *(`migration_ajustes.sql`.)*
- **Carrinho de emergência.** Itens, lacre, conferência.
- **Escrituração / BMPO.** Livro de Registro derivado; balanço mensal; custódia fora do BMPO (salvo quando integrada).
- **Financeiro.** Somente custos de farmácia (sem diária de internação).
- **Prescritor externo.** Vínculo interno/externo com tag. *(`migration_prescritor_externo.sql`.)*
- **Consultoria — Padronização.** Planilha `Padronizacao_Reviva_v1.xlsx` (67 itens por DCB, controlados marcados, sugestões do RT).

---

## 3. Estado do sistema (checklist de conferência)

### 3.1 Banco (Supabase) — bloco SQL de verificação
Cole no **SQL Editor**. Não altera nada; só informa o que está aplicado.

```sql
select 'schema base (tabela pacientes)' as item,
       case when exists (select 1 from information_schema.tables where table_name='pacientes')
            then 'OK' else 'FALTA — rodar schema.sql' end as status
union all
select 'migration_ajustes (ajustes_estoque)',
       case when exists (select 1 from information_schema.tables where table_name='ajustes_estoque')
            then 'OK' else 'FALTA — migration_ajustes.sql' end
union all
select 'migration_prescritor_externo (prescritores.externo)',
       case when exists (select 1 from information_schema.columns
                         where table_name='prescritores' and column_name='externo')
            then 'OK' else 'FALTA — migration_prescritor_externo.sql' end
union all
select 'migration_cotacao (cotacao_precos)',
       case when exists (select 1 from information_schema.tables where table_name='cotacao_precos')
            then 'OK' else 'FALTA — migration_cotacao.sql' end
union all
select 'migration_alta (custodia_destinos)',
       case when exists (select 1 from information_schema.tables where table_name='custodia_destinos')
            then 'OK' else 'FALTA — migration_alta.sql' end
union all
select 'migration_qtd_dose (prescricoes.qtd_por_horario)',
       case when exists (select 1 from information_schema.columns
                         where table_name='prescricoes' and column_name='qtd_por_horario')
            then 'OK' else 'FALTA — migration_qtd_dose.sql' end
union all
select 'migration_pops (pops.codigo / campos de controle)',
       case when exists (select 1 from information_schema.columns
                         where table_name='pops' and column_name='codigo')
            then 'OK' else 'FALTA — migration_pops.sql' end
union all
select 'migration_pops_corpo (pops.corpo)',
       case when exists (select 1 from information_schema.columns
                         where table_name='pops' and column_name='corpo')
            then 'OK' else 'FALTA — migration_pops_corpo.sql' end
union all
select 'migration_fornecedor_qualif (fornecedores.aval_prazo)',
       case when exists (select 1 from information_schema.columns
                         where table_name='fornecedores' and column_name='aval_prazo')
            then 'OK' else 'FALTA — migration_fornecedor_qualif.sql' end;
```

Regras de ouro: migrações são **seguras de repetir** (`if not exists`); **nunca** rodar `schema.sql`, `seed_teste.sql` ou `reset_para_comecar.sql` com dados reais. Ordem numa instalação limpa: schema → ajustes → prescritor_externo → cotacao → alta → qtd_dose → pops → pops_corpo (+ pops_conteudo_inicial).

### 3.2 Telas (Vercel) — o sinal visível de cada recurso
- [ ] **Pacientes**: abas Internados / Arquivo; "Dar alta"; Extrato de Alta com/sem valores.
- [ ] **Prescrições**: lista por paciente (cartões); filtro por paciente; editar/suspender/adicionar; campo Qtd/horário; **impressão de Folha de Prescrição Médica (prontuário), Receituário C (2 vias) e comum**, pré-preenchidos ou **em branco**.
- [ ] **Dispensação**: seletor de data; "★ custódia do paciente" no lote; Qtd/horário aplicada.
- [ ] **Mapa**: botões "por paciente" e "por dia"; toggle sem-prescrição; fichas em branco.
- [ ] **Medicação do Paciente**: situação (custódia / aguardando / devolvido / integrado); devolver à família / integrar ao estoque.
- [ ] **Ajuste de Estoque**: "Folha de contagem" com 3 filtros (substância, vencimento, zerados).
- [ ] **Cotação**: abas Itens / Lançar preços / Comparativo & Pedidos; **Qualificação de fornecedor** (habilitação + desempenho) com tags e alerta; itens **por categoria**, só da padronização; pedido impresso agrupado.
- [ ] **Livro de Registro**: filtros (paciente, período, tipo, substância, lista, lote); colunas Lote e Validade; saldo real. **Folha de Registro Semanal** (por princípio ativo + dosagem) no topo da tela.
- [ ] **Balanço/BMPO**: uma linha por princípio ativo + dosagem, com nomes comerciais como referência.
- [ ] **Enfermagem — Documentos e Registros**: folha de Sinais Vitais imprimível, com paciente ou em branco.
- [ ] **POPs do Fluxo**: registro com CRUD, status clicável, controle (código/versão/vigência/revisão), "Registro mestre", editor de conteúdo e impressão do POP formatado. **14 POPs redigidos**, ordenados por código (FAR antes de ENF).

Se algo faltar: rode só a migração indicada (3.1) e/ou suba o `reviva-app.zip` mais recente; Ctrl+F5; F12 → Console em caso de erro.

---

## 4. Evoluções futuras / possibilidades de expansão

Priorizado por valor regulatório e esforço. **P1 = próximo**, **P2 = médio prazo**, **P3 = quando fizer sentido**.

### Receituários e Notificações (P2)
- ✅ Receituário de Controle Especial (C, 2 vias) e Receituário comum imprimíveis pelo sistema.
- Notificação B (azul) e A (amarela): dependem de numeração da VISA e de modelo Versão 2 da Anvisa; avaliar impressão pelo sistema quando a numeração estiver disponível. Confirmar rito com a VISA-GO.

### Fase POPs (P1) — Camadas 1 e 2 concluídas (21/07/2026)
Reestruturar a área de POPs, hoje um checklist estático e somente-leitura (tópicos cadastrados como dado de teste, botão sem ação).
- ✅ **Camada 1 (concluída):** registro/checklist funcional — CRUD, status clicável, campos de controle, tópicos permanentes e impressão do registro mestre.
- ✅ **Camada 2 (concluída):** corpo estruturado + impressão do documento formatado. Todos os **13 POPs do fluxo** redigidos com corpo estruturado e impressão formatada. Próximo: revisar em conjunto e coletar assinaturas; incrementar versões conforme a estrutura evoluir.
- **Camada 2 (esforço médio):** gerador de documento — corpo estruturado (objetivo, campo de aplicação, responsabilidades, materiais, procedimento passo a passo, registros, referências, histórico de revisões, assinaturas) e **impressão do POP formatado**. Redação dos POPs do fluxo pode ser rascunhada a partir do funcionamento real do sistema.
- POPs do fluxo a contemplar: admissão/cadastro; conferência de NF; doações; **custódia + destino na alta**; preparo/etiquetagem da dose unitária; **dupla checagem/administração**; devolução/reintegração de SOS; carrinho de emergência/lacre; **escrituração e balanço**; **ajuste/contagem de inventário**; **cotação/compras**; backup/continuidade.

### Escrituração e Livro (P1–P2)
- **Fechar/travar semana** da escrituração (integridade após impressão e assinatura) — evita edição retroativa de período já oficializado.
- **Resumo consolidado** no rodapé do Livro filtrado (ex.: total de entradas/saídas por substância no período).
- **Transferência custódia → estoque** como lançamento explícito no Livro (hoje a integração muda a natureza do lote sem gerar movimento de saldo).
- Impressão do Livro em **paisagem** se as 9 colunas ficarem apertadas em retrato.

### Compras e fornecedores (P2)
- **Previsão de compra por consumo** (quando houver histórico de dispensação): uso/dia, dias de cobertura, sugestão de compra — reaproveitando a lógica da planilha de 2019.
- ✅ **Qualificação de fornecedores** (habilitação documental + desempenho Bom/Regular/Ruim) — concluída. Pendente: disparo de e-mail de cotação direto do sistema.

### Inventário (P2)
- Folha de contagem **por local de armazenamento** (prateleira/geladeira) para contagem em pontos diferentes da farmácia.

### Plataforma (P3)
- **Multiusuário com perfis** (farmácia, enfermagem, direção) sobre a base de `usuarios` já existente.
- ✅ **Backup Exportar/Importar** no sistema (export periódico + restauração) — concluído. Próximo: PWA com cache de leitura (abrir/imprimir offline) e retaguarda fria (2º projeto Postgres).
- **Relatórios gerenciais** (consumo por período, curva ABC, perdas por ajuste).

---

## 5. Convenções de manutenção
- Toda entrega vem como `reviva-app.zip`; a pasta `db/` traz todas as migrações + este documento.
- Cada release: atualizar a seção 2 (memorial) e, se entrar recurso novo, a seção 3.2 e a seção 4.
- Validação de cada mudança em Postgres local + conferência de sintaxe antes da entrega. O que não é testável no ambiente (cliques na interface) é sinalizado para conferência no primeiro uso real.
